import mongoose, { mongo } from 'mongoose';

const doctorSchema = new mongoose.Schema({
    name:{
      type:String,
      required:true,
    },

    salary:{
      type:Number,
      required:true,
    },

    qualification:{
      type:String, 
      required:true,
    },

    experianceInyears:{
      type:Number,
      default:0,
    },

    worksInHosptial:{
      type:mongoose.Schema.Types.ObjectId,
      ref:'Hospital',
    },

    

})


export const Doctor = mongoose.model("Doctor", doctorSchema)
