import mongoose, { mongo } from 'mongoose';

const patientSchema = new mongoose.Schema({
  name:{
    type:String, 
    requried:true,
  },

  diagonsedwith:{
      type:String,
      requried:true,
  },

  address:{
    type:String,
    required:true,
  },

  age:{
    type:Number,
    required:true,
  },

  bloodGroups:{
    type:String,
    // we can also use here, enum
    required:true,
  },

  gender:{
    type:String,
    required:true,
    enum:["M","O","F"],
  },

  admittedIn:{
    type:mongoose.Schema.Types.ObjectId,
    ref:'Hospital', 
    required:true,

  },



},{
  timestamps:true,
})

export const patient = mongoose.model("Patient", patientSchema)